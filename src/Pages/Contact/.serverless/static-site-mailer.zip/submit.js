//to be called once form is validated
//we need the values of the fields
//then convert the fields and corresponding values to an obj that gets
// the stringify json treatment

export default function submitValidatedData(values){
  const formData = JSON.stringify(values)


  /*
  const form
  let xhr = new XMLHttpRequest();

  xhr.open(form.method, form.action, true)
  xhr.setRequestHeader("Accept", "application/json; charset=UTF-8");
  xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");

  xhr.send(formData);

  xhr.onloadend = response => {
    if(response.target.status === 200){
      //Successful submission
      form.reset()

    }
  }  */


}
